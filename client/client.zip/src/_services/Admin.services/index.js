export {service,
    AllService,
    createBank,
    AllBank,
    AllBankOffer,
    saveBankOffer,
    Applications,
    ApplicationsById,
    ApplicationsStateChange,
    ShareRefralDataSave,
    productDataSave,
    ApplyLoans
} from './admin.services'