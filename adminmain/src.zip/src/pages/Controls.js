import { Button, Checkbox, Input, RadioGroup, Select } from '@mui/material';
const Controls =  {
 Input,
 RadioGroup,
 Select,
 Checkbox,
 Button
}

export default Controls;