import React ,{useState} from 'react';


const About = () => {



  return (
    
    
  <div className="container contact">
      <div className="head mb-3" >
    <h1>ABOUT CreditsIn </h1>
  </div>
    
 
  <div style={{textAlign : 'justify'}}>
    <p>
CreditsIn is a leading unique and diversified platform for your business. we are your companion for credit partnership. Our platform provides your business with a unique and diversified range of funding options. We offer great deals for customers to earn money-back on purchases or services delivered. Every customer can earn a surprise bonus upto Rs.20,000/- on every purchase with CreditsIn. 
Creditsin is a multi-product sales and service platform where businesses may promote or sell their products and services in order to gain mass orders for their business. Customers that use the Creditsin platform will save money by claiming Cash rewards and other seasonal offers on Creditsin. Users can also earn referral bonuses to earn additional income.
</p>
 <h3>Our Team</h3>
 <p>
 Our highly experienced team of professionals creates technologies in an unified and effective manner.We will create an action plan with the direction and support of our experienced team of professionals from a wide variety of specialist disciplines, and we will help you realise those so that you acquire the best possible results.
 </p>
<h3>Our vision</h3>
<p>
Our bonus and cash back system for every customer is a gift of delight on every payout for any purchase or service. We seek to build a platform that will allow all customers to benefit from each purchase. Our objective is to develop a platform where all customers, regardless of financial status, may benefit from each transaction.
</p>
<h3>Our mission</h3>
<p>
In order to achieve our mission, we strive to create an environment with satisfied happy customers, so they can take the next step towards getting their dream product or service with the best offers and cashbacks with CreditsIn.
</p>
</div>
</div>
  );
};

export default About;

