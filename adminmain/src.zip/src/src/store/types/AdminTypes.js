export const SET_LOADER = "SET_LOADER";
export const CLOSE_LOADER = "CLOSE_LOADER";
export const LOGIN_ERRORS = "LOGIN_ERRORS";
export const SET_TOKEN  = 'SET_TOKEN';
export const SET_MESSAGE = "SET_MESSAGE";
export const REMOVE_MESSAGE = "REMOVE_MESSAGE";
export const SET_ADMIN = "SET_ADMIN";
export const USERSARRAY = "USERSARRAY";
