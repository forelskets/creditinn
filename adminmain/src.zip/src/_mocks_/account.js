// ----------------------------------------------------------------------

const account = {
  displayName: 'CreditsIN',
  email: 'info@creditsin.com',
  photoURL: '/static/mock-images/avatars/avatar_default.jpg'
};

export default account;
